module.exports = {
  HOST: "localhost",
  USER: "root",
  PASSWORD: "",
  DB: "sg_db"
};